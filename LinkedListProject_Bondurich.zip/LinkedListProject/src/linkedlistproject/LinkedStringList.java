package linkedlistproject;

/**
 * @author Stephen Bondurich
 * Nov 7, 2018
 *
 * 
 */
import java.util.NoSuchElementException;

public class LinkedStringList {
	private Node first;
	private Node currentNode;
	private int length;
	
	class Node implements Comparable<Node> {
		private String data;
		private Node next;
		
		@Override
		public int compareTo(Node n) {
			return this.data.compareTo(n.data);
                        //im really proud of how concise this override is
		}
		
		public void printNodeData() {
			System.out.println("Node data: " + data);
		}

		public Node getNext() {
			return next;
		}
	}

	public LinkedStringList() {
		first = null;
		currentNode = null;
		length = 0;
	}

	public void addFirst(String value) {
		Node newNode = new Node();
		newNode.data = value;
		newNode.next = first;
		first = newNode;
		currentNode = newNode;
		length++;
	}
	
	//my new method
	public void add(String value) {
                if (first == null){
                    addFirst(value);
                }
                else{
		Node newNode = new Node();
		newNode.data = value;
		newNode.next = currentNode.next;
		currentNode.next = newNode;
		currentNode = newNode;
		length++;
                }
	}
	
	//my new method
	public void removeFirst() {
		if (first!=null) {
			if (currentNode == first) {
				currentNode = first.next;
			}
			first = first.next;
			length--;
		}
                else{
                    throw new NoSuchElementException();
                }
	}
	
	//my new helper method, not specified by the assignment but it helps a LOT
	//it returns the node right behind currentNode
	private Node getPreviousNode() {
		Node temp = first;
		if (currentNode == first) {
			return null;
		}
		
		while(temp.next != currentNode) {
			temp = temp.next;
		}//when this loop ends, temp is the node right before the current one
		return temp;
	}
	
	//my new method
	public void remove() {
		if (currentNode != null) {
			if (currentNode == first) {
				removeFirst();
			}
			else {
				Node temp = getPreviousNode();
				temp.next = currentNode.next;
				currentNode = currentNode.next;
				length--;
			}
			//and garbage collection does the rest
		}
                else{
                    throw new NoSuchElementException();
                }
	}
		

	//my new method
	public Node getMinNode(Node starterNode) {
		Node smallest = starterNode;
		Node checker = smallest.next;
		while( checker!=null) {
			if(checker.compareTo(smallest)<0) {
				smallest = checker;
			}
			checker = checker.next;
		}
		
		return smallest;
	}
	
	//my new method
	public void swapNodes(Node a, Node b) {
		Node placeHolder = currentNode;

		currentNode = a;
		Node nodeBehindA = getPreviousNode();
		currentNode = b;
		Node nodeBehindB = getPreviousNode();
		
		if(nodeBehindB == null) {
			first =a;
		}
		else{
			nodeBehindB.next = a;
		}
		
		if(nodeBehindA==null) {
			first = b;
		}
		else {
			nodeBehindA.next = b;
		}
		
		Node temp = a.next;
		a.next = b.next;
		b.next = temp;
		
		currentNode = placeHolder;
		
	}
	
	//my new method
	public void sortAscending() {
		Node startingPoint = first;
		Node newestMin = first.next;
		
		for (int i = 0; i <length; i++) {
			newestMin = getMinNode(startingPoint);
			swapNodes(startingPoint, newestMin);
			startingPoint = newestMin.next;
		}
	}
	public void moveNext() {
		if (currentNode.next == null) {
			throw new NoSuchElementException();
		} else {
			currentNode = currentNode.next;
		}
	}

        
        //my new method
        
        public int indexOf(String value){
            int counter = 0;
            Node temp = first;
            
            for (int i=0; i < length; i++){
                if (temp.data.equals(value)){
                    return counter;
                }
                counter++;
                temp = temp.next;
            }
            
            
            return -1;
        
        }
	public void moveFirst() {
		currentNode = first;
	}

	public boolean isEmpty() {
		return (first == null);
	}

	public int getLength() {
		return length;
	}

	public String getFirstValue() {
		if (first == null) {
			throw new NoSuchElementException();
		} else {
			return first.data;
		}
	}
        //my new method
        public void setCurrentValue(String value){
            currentNode.data = value;
        }
	public String getCurrentValue() {
		if (currentNode == null) {
			throw new NoSuchElementException();
		} else {
			return currentNode.data;
		}
	}
	
	public void displayList() {
		Node tempNode = first;
		System.out.println("List contents: ");
		
		while (tempNode != null) {
			tempNode.printNodeData();
			tempNode = tempNode.getNext();
		}
	}
	
	
}